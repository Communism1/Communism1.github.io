---
layout: post
title: "Sample Link Post"
excerpt: "Try click on the link icon."
categories: [link post]
link: http://renyuanz.github.io
share: true
---

This theme supports **link posts**, made famous by John Gruber. To use, just add `link: http://url-you-want-linked` to the post's YAML front matter and you're done.

> And this is how a quote looks.

Some [link](http://renyuanz.github.io) can also be shown.
